package hello;

public final class Constants {

   /**
     * The application scope attribute under which our user database
     * is stored.
     */
    public static final String PERSON_KEY = "personbean";

}
